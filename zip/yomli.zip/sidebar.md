---
Title: Sidebar
Status: shared
Description: Maître philosophe, modeste éditeur, geek à ses heures et parfois développeur web. Aime le thé noir et le riz cantonnais.
Links: Email->javascript:window.location.href='mailto:'+['yomli','yom.li'].join('@') | DM->https://twitter.com/messages/compose?recipient_id=218543902 | Pourboire->https://paypal.me/GuillaumeLitaudon
---

